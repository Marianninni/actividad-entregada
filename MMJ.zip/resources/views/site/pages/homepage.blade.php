@extends('site.app')
@section('title', 'Homepage')

@section('content')
    <h2>Homepage</h2>
@stop